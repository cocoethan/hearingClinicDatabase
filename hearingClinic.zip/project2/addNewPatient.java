import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class addNewPatient extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			addNewPatient dialog = new addNewPatient();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public addNewPatient() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new GridLayout(0, 2, 0, 0));
		//BEGIN MAX EDIT
				{
					JLabel lblNewLabel = new JLabel("* First Name");
					contentPanel.add(lblNewLabel);
				}
				{
					textField = new JTextField();
					contentPanel.add(textField);
					textField.setColumns(10);
				}
				{
					JLabel lblNewLabel_1 = new JLabel("o Middle Name");
					contentPanel.add(lblNewLabel_1);
				}
				{
					textField_1 = new JTextField();
					contentPanel.add(textField_1);
					textField_1.setColumns(10);
				}
				{
					JLabel lblNewLabel_2 = new JLabel("* Last Name");
					contentPanel.add(lblNewLabel_2);
				}
				{
					textField_2 = new JTextField();
					contentPanel.add(textField_2);
					textField_2.setColumns(10);
				}
				{
					JLabel lblNewLabel_3 = new JLabel("* Date Of Birth");
					contentPanel.add(lblNewLabel_3);
				}
				{
					textField_3 = new JTextField();
					contentPanel.add(textField_3);
					textField_3.setColumns(10);
				}
				{
					JLabel lblNewLabel_4 = new JLabel("* Gender");
					contentPanel.add(lblNewLabel_4);
				}
				{
					textField_4 = new JTextField();
					contentPanel.add(textField_4);
					textField_4.setColumns(10);
				}
				{
					JLabel lblNewLabel_5 = new JLabel("* Phone");
					contentPanel.add(lblNewLabel_5);
				}
				{
					textField_5 = new JTextField();
					contentPanel.add(textField_5);
					textField_5.setColumns(10);
				}
				{
					JLabel lblNewLabel_6 = new JLabel("o E-mail");
					contentPanel.add(lblNewLabel_6);
				}
				{
					textField_6 = new JTextField();
					contentPanel.add(textField_6);
					textField_6.setColumns(10);
				}
				{
					JLabel lblNewLabel_7 = new JLabel("* Street Address");
					contentPanel.add(lblNewLabel_7);
				}
				{
					textField_7 = new JTextField();
					contentPanel.add(textField_7);
					textField_7.setColumns(10);
				}
				{
					JLabel lblNewLabel_8 = new JLabel("* City");
					contentPanel.add(lblNewLabel_8);
				}
				{
					textField_8 = new JTextField();
					contentPanel.add(textField_8);
					textField_8.setColumns(10);
				}
				{
					JLabel lblNewLabel_9 = new JLabel("o State");
					contentPanel.add(lblNewLabel_9);
				}
				{
					textField_9 = new JTextField();
					contentPanel.add(textField_9);
					textField_9.setColumns(10);
				}
				{
					JLabel lblNewLabel_10 = new JLabel("* Zip");
					contentPanel.add(lblNewLabel_10);
				}
				{
					textField_10 = new JTextField();
					contentPanel.add(textField_10);
					textField_10.setColumns(10);
				}
				{
					JLabel lblNewLabel_11 = new JLabel("* Country");
					contentPanel.add(lblNewLabel_11);
				}
				{
					textField_11 = new JTextField();
					contentPanel.add(textField_11);
					textField_11.setColumns(10);
				}
				{
					JLabel lblNewLabel_12 = new JLabel("o Photo");
					contentPanel.add(lblNewLabel_12);
				}
				{
					textField_12 = new JTextField();
					contentPanel.add(textField_12);
					textField_12.setColumns(10);
				}
				{
					JLabel lblNewLabel_13 = new JLabel("o Social Security Number");
					contentPanel.add(lblNewLabel_13);
				}
				{
					textField_13 = new JTextField();
					contentPanel.add(textField_13);
					textField_13.setColumns(10);
				}
				{
					JLabel lblNewLabel_14 = new JLabel("o Insurance");
					contentPanel.add(lblNewLabel_14);
				}
				{
					textField_14 = new JTextField();
					contentPanel.add(textField_14);
					textField_14.setColumns(10);
				}
				//END MAX EDIT
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnNewButton = new JButton("Save");
				buttonPane.add(btnNewButton);
			}
			{
				JButton okButton = new JButton("Add Demographics");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						addDemographics newWindow = new addDemographics();
						newWindow.setVisible(true);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton btnNewButton_1 = new JButton("Add New Visit");
				buttonPane.add(btnNewButton_1);
				btnNewButton_1.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						addNewVisit newWindow = new addNewVisit();
						newWindow.setVisible(true);
					}
				});
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
