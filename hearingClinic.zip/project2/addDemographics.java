import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class addDemographics extends JDialog {

	private final JPanel contentPanel = new JPanel();
	//BEGIN MAX EDIT
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		private JTextField textField_3;
		private JTextField textField_4;
		private JTextField textField_5;
		private JTextField textField_6;
		private JTextField textField_7;
		//END MAX EDIT
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			addDemographics dialog = new addDemographics();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public addDemographics() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			//BEGIN MAX EDIT
			setBounds(100, 100, 450, 300);
			getContentPane().setLayout(new BorderLayout());
			contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(contentPanel, BorderLayout.CENTER);
			contentPanel.setLayout(new GridLayout(0, 2, 0, 0));
			{
				JLabel lblNewLabel = new JLabel("o Occupation");
				contentPanel.add(lblNewLabel);
			}
			{
				textField = new JTextField();
				contentPanel.add(textField);
				textField.setColumns(10);
			}
			{
				JLabel lblNewLabel_1 = new JLabel("o Work Status");
				contentPanel.add(lblNewLabel_1);
			}
			{
				textField_1 = new JTextField();
				contentPanel.add(textField_1);
				textField_1.setColumns(10);
			}
			{
				JLabel lblNewLabel_2 = new JLabel("o Educational Degree");
				contentPanel.add(lblNewLabel_2);
			}
			{
				textField_2 = new JTextField();
				contentPanel.add(textField_2);
				textField_2.setColumns(10);
			}
			{
				JLabel lblNewLabel_3 = new JLabel("o Tinnitus Onset");
				contentPanel.add(lblNewLabel_3);
			}
			{
				textField_3 = new JTextField();
				contentPanel.add(textField_3);
				textField_3.setColumns(10);
			}
			{
				JLabel lblNewLabel_4 = new JLabel("o Tinnitus Etiology");
				contentPanel.add(lblNewLabel_4);
			}
			{
				textField_4 = new JTextField();
				contentPanel.add(textField_4);
				textField_4.setColumns(10);
			}
			{
				JLabel lblNewLabel_5 = new JLabel("o Hyperacusis Onset");
				contentPanel.add(lblNewLabel_5);
			}
			{
				textField_5 = new JTextField();
				contentPanel.add(textField_5);
				textField_5.setColumns(10);
			}
			{
				JLabel lblNewLabel_6 = new JLabel("o Hyperacusis Etiology");
				contentPanel.add(lblNewLabel_6);
			}
			{
				textField_6 = new JTextField();
				contentPanel.add(textField_6);
				textField_6.setColumns(10);
			}
			{
				JLabel lblNewLabel_7 = new JLabel("o Additional Comments");
				contentPanel.add(lblNewLabel_7);
			}
			{
				textField_7 = new JTextField();
				contentPanel.add(textField_7);
				textField_7.setColumns(10);
			}
			//END MAX EDIT
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnNewButton = new JButton("Save");
				buttonPane.add(btnNewButton);
			}
			{
				JButton btnNewButton_1 = new JButton("Add New Visit");
				buttonPane.add(btnNewButton_1);
				btnNewButton_1.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						addNewVisit newWindow = new addNewVisit();
						newWindow.setVisible(true);
					}
				});
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
