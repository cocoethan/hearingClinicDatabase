import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class addNewVisit extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			addNewVisit dialog = new addNewVisit();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public addNewVisit() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setResizable(false);
		setBounds(100, 100, 527, 405);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Visit ID:");
			lblNewLabel.setBounds(29, 13, 46, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			textField = new JTextField();
			textField.setBounds(85, 10, 86, 20);
			textField.setHorizontalAlignment(SwingConstants.LEFT);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Date:");
			lblNewLabel_1.setBounds(189, 13, 46, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			textField_1 = new JTextField();
			textField_1.setBounds(240, 10, 86, 20);
			contentPanel.add(textField_1);
			textField_1.setColumns(10);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Patient:");
			lblNewLabel_2.setBounds(29, 38, 46, 14);
			contentPanel.add(lblNewLabel_2);
		}
		{
			textField_2 = new JTextField();
			textField_2.setBounds(85, 35, 136, 20);
			contentPanel.add(textField_2);
			textField_2.setColumns(10);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("THC#:");
			lblNewLabel_3.setBounds(240, 38, 46, 14);
			contentPanel.add(lblNewLabel_3);
		}
		{
			JLabel lblNewLabel_4 = new JLabel("Visit no.");
			lblNewLabel_4.setBounds(353, 38, 46, 14);
			contentPanel.add(lblNewLabel_4);
		}
		{
			JSeparator separator = new JSeparator();
			separator.setBounds(404, 44, 0, 2);
			contentPanel.add(separator);
		}
		{
			JButton btnNewButton = new JButton("Interview");
			btnNewButton.setBounds(29, 229, 86, 46);
			contentPanel.add(btnNewButton);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					interview newWindow = new interview();
					newWindow.setVisible(true);
				}
			});
		}
		
		JButton btnNewButton_1 = new JButton("Audiology");
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(146, 229, 89, 46);
		contentPanel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Medical other");
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.setEnabled(false);
		btnNewButton_2.setBounds(262, 229, 89, 46);
		contentPanel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Diagnose");
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setEnabled(false);
		btnNewButton_3.setBounds(391, 229, 89, 46);
		contentPanel.add(btnNewButton_3);
		
		JLabel lblNewLabel_5 = new JLabel("Problem:");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_5.setBounds(29, 69, 62, 14);
		contentPanel.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBackground(Color.WHITE);
		textField_5.setBounds(85, 66, 46, 20);
		contentPanel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Category:");
		lblNewLabel_6.setBounds(152, 69, 69, 14);
		contentPanel.add(lblNewLabel_6);
		
		textField_6 = new JTextField();
		textField_6.setBackground(Color.WHITE);
		textField_6.setBounds(208, 66, 27, 20);
		contentPanel.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Protocol:");
		lblNewLabel_7.setBounds(250, 69, 64, 14);
		contentPanel.add(lblNewLabel_7);
		
		textField_7 = new JTextField();
		textField_7.setBackground(Color.WHITE);
		textField_7.setBounds(299, 66, 27, 20);
		contentPanel.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("FU:");
		lblNewLabel_8.setBounds(29, 100, 46, 14);
		contentPanel.add(lblNewLabel_8);
		
		textField_8 = new JTextField();
		textField_8.setBackground(Color.WHITE);
		textField_8.setBounds(85, 94, 46, 20);
		contentPanel.add(textField_8);
		textField_8.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Instrument:");
		lblNewLabel_9.setBounds(152, 100, 76, 14);
		contentPanel.add(lblNewLabel_9);
		
		textField_9 = new JTextField();
		textField_9.setBackground(Color.WHITE);
		textField_9.setBounds(218, 94, 56, 20);
		contentPanel.add(textField_9);
		textField_9.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("REM:");
		lblNewLabel_10.setBounds(284, 100, 46, 14);
		contentPanel.add(lblNewLabel_10);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setBackground(Color.WHITE);
		chckbxNewCheckBox.setBounds(324, 93, 27, 23);
		contentPanel.add(chckbxNewCheckBox);
		
		JLabel lblNewLabel_11 = new JLabel("Comments:");
		lblNewLabel_11.setBounds(29, 129, 79, 14);
		contentPanel.add(lblNewLabel_11);
		
		textField_10 = new JTextField();
		textField_10.setBackground(Color.WHITE);
		textField_10.setBounds(95, 125, 365, 57);
		contentPanel.add(textField_10);
		textField_10.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Next Visit:");
		lblNewLabel_12.setBounds(29, 196, 79, 14);
		contentPanel.add(lblNewLabel_12);
		
		textField_11 = new JTextField();
		textField_11.setBackground(Color.LIGHT_GRAY);
		textField_11.setEditable(false);
		textField_11.setEnabled(false);
		textField_11.setBounds(105, 193, 86, 20);
		contentPanel.add(textField_11);
		textField_11.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("Instrument Details");
		btnNewButton_4.setBackground(Color.LIGHT_GRAY);
		btnNewButton_4.setEnabled(false);
		btnNewButton_4.setHorizontalAlignment(SwingConstants.TRAILING);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_4.setBounds(29, 286, 86, 46);
		contentPanel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("REM Details");
		btnNewButton_5.setBackground(Color.LIGHT_GRAY);
		btnNewButton_5.setEnabled(false);
		btnNewButton_5.setBounds(146, 286, 89, 46);
		contentPanel.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Counseling Details");
		btnNewButton_6.setBackground(Color.LIGHT_GRAY);
		btnNewButton_6.setEnabled(false);
		btnNewButton_6.setBounds(262, 286, 89, 46);
		contentPanel.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Recommend Treatment");
		btnNewButton_7.setBackground(Color.LIGHT_GRAY);
		btnNewButton_7.setEnabled(false);
		btnNewButton_7.setBounds(391, 286, 89, 46);
		contentPanel.add(btnNewButton_7);
		
		textField_3 = new JTextField();
		textField_3.setBounds(280, 35, 46, 20);
		contentPanel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(404, 35, 46, 20);
		contentPanel.add(textField_4);
		textField_4.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
