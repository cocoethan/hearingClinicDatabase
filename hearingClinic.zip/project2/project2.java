import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.BoxLayout;
import java.awt.Color;

public class project2 extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			project2 dialog = new project2();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			initialWarning newWarning = new initialWarning();
			newWarning.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public project2() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			btnNewButton = new JButton("Patients");
			btnNewButton.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					patients newWindow = new patients();
					newWindow.setVisible(true);
				}
			});
		}
		{
			btnNewButton_1 = new JButton("Visits");
			btnNewButton_1.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					visits newWindow = new visits();
					newWindow.setVisible(true);
				}
			});
		}
		{
			btnNewButton_2 = new JButton("Other");
			btnNewButton_2.setBackground(Color.LIGHT_GRAY);
			btnNewButton_2.setEnabled(false);
		}
		contentPanel.setLayout(new GridLayout(0, 2, 5, 5));
		contentPanel.add(btnNewButton);
		contentPanel.add(btnNewButton_1);
		contentPanel.add(btnNewButton_2);
	}

}
