import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JRadioButton;
import java.awt.Insets;

public class questionnaire extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			questionnaire dialog = new questionnaire();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public questionnaire() {
		setBounds(100, 100, 800, 775);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{0, 13, 11, 0, 0, 0, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPanel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel lblNewLabel = new JLabel("1. Because of your tinnitus, is it difficult for you to conecntrate?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.gridwidth = 4;
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 1;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 1;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_1 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_1.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_1.gridx = 5;
			gbc_rdbtnNewRadioButton_1.gridy = 1;
			contentPanel.add(rdbtnNewRadioButton_1, gbc_rdbtnNewRadioButton_1);
		}
		{
			JRadioButton rdbtnNewRadioButton = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton = new GridBagConstraints();
			gbc_rdbtnNewRadioButton.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton.gridx = 6;
			gbc_rdbtnNewRadioButton.gridy = 1;
			contentPanel.add(rdbtnNewRadioButton, gbc_rdbtnNewRadioButton);
		}
		{
			JLabel lblNewLabel = new JLabel("2. Does the loudness of you tinnitus make it difficult for you to hear people?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.gridwidth = 3;
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 2;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 2;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 2;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 2;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("3. Does your tinnitus make you angry?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 3;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 3;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 3;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 3;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("4. Does you tinnitus make you feel confused?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 4;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 4;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 4;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 4;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("5. Because of your tinnitus, do you feel desperate?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 5;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 5;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 5;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 5;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("6. Do you complain a great deal about your tinnitus?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 6;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 6;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 6;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 6;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("7. Because of your tinnitus, do you have trouble falling asleep at night?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 7;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 7;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 7;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 7;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("8. Do you feel like you cannot escape your tinnitus?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 8;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 8;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 8;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 8;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("9. Does tinnitus interfere with your ability to enjoy social activities?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 9;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 9;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 9;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 9;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("10. Because of your tinnitus, do you feel frustrated?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 10;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 10;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 10;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 10;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("11. Because of your tinnitus, do you feel that you have a terrible disease?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 11;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 11;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 11;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 11;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("12. Does your tinnitus make it difficult for you to enjoy life?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 12;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 12;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 12;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 12;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("13. Does your tinnitus interfere with your job or household responsibilities?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.gridwidth = 3;
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 13;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 13;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 13;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 13;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("14. Because of your tinnitus, do you find that you are often irritable?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 14;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 14;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 14;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 14;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("15. Because of your tinnitus, is it difficult to read?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 15;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 15;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 15;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 15;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("16. Does your tinnitus make you upset?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 16;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 16;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 16;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 16;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("17. Do you feel that your tinnitus problem has placed stress on your relationships?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.gridwidth = 4;
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 17;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 17;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 17;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 17;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("18. Do you find it difficult to focus your attention away from your tinnitus?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 18;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 18;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 18;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 18;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("19. Do you feel that you have no control over your tinnitus?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 19;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 19;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 19;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 19;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("20. Because of your tinnitus, do you often feel tired?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 20;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 20;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 20;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 20;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("21. Because of your tinnitus, do you feel depressed?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 21;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 21;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 21;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 21;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("22. Does your tinnitus make you feel anxious?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 22;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 22;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 22;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 22;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("23. Do you feel that you can no longer cope with your tinnitus?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 23;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 23;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 23;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 23;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("24. Does your tinnitus get worse when you are under stress?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 24;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 24;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 24;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 24;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JLabel lblNewLabel = new JLabel("25. Does your tinnitus make you feel insecure?");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.HORIZONTAL;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 0;
			gbc_lblNewLabel.gridy = 25;
			contentPanel.add(lblNewLabel, gbc_lblNewLabel);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Yes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 4;
			gbc_rdbtnNewRadioButton_2.gridy = 25;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Sometimes");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 5);
			gbc_rdbtnNewRadioButton_2.gridx = 5;
			gbc_rdbtnNewRadioButton_2.gridy = 25;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("No");
			GridBagConstraints gbc_rdbtnNewRadioButton_2 = new GridBagConstraints();
			gbc_rdbtnNewRadioButton_2.insets = new Insets(0, 0, 5, 0);
			gbc_rdbtnNewRadioButton_2.gridx = 6;
			gbc_rdbtnNewRadioButton_2.gridy = 25;
			contentPanel.add(rdbtnNewRadioButton_2, gbc_rdbtnNewRadioButton_2);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
